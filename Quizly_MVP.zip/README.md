# Quizly MVP

A functional, mobile-first Quizly study app prototype.

## Run it
Open `index.html` in a browser. For installable PWA behavior/service worker, serve the folder from a local web server or deploy it to a static host.

## Included
- Quizly branding/UI
- Photo upload preview
- Notes input
- AI-style lesson generation from entered notes
- Flashcards with flip/navigation
- Interactive 5-question quiz
- Study plan
- Progress dashboard
- Mobile navigation
- PWA manifest + service worker

## Turning the prototype into real AI
Do NOT put an OpenAI/API key in the browser. Add a server endpoint such as `/api/study` and have that server call the model provider. The endpoint can accept extracted text and return structured JSON for:
- explanation
- key takeaways
- flashcards
- quiz questions
- weak-topic recommendations

For photo/PDF support, add a secure upload/OCR pipeline on the server.
